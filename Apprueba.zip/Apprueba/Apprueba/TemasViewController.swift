//
//  TemasViewController.swift
//  Apprueba
//
//  Created by 2020-1 on 12/3/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import Firebase
import FirebaseUI
import MobileCoreServices

class TemasViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    var arre: [inf] = [inf]()
    var selec: String = ""
    var portadas: String = ""
    var port: String = ""
    var temas: [String] = []
    var bolita: IndexPath = []
   
    
    
    
    @IBOutlet weak var portada: UIImageView!
    @IBOutlet weak var tabla: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        obtener(str: portadas)
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return temas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tabla.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! TemTableViewCell
        
        cell.label.text = temas[indexPath.row]
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let esco = segue.destination as! teoejerViewController
        let myIndexPath = tabla.indexPathForSelectedRow
        esco.arre = arre
        esco.bolita = bolita
        if "\(arre[0].Temas[(myIndexPath?.row)!])" == "\(arre[0].Temas[0])"{
            esco.ejer = arre[0].Ejer[0].Tema1
            esco.teoria = arre[0].Teo[0].Tema1
        }else if "\(arre[0].Temas[(myIndexPath?.row)!])" == "\(arre[0].Temas[1])"{
            esco.ejer = arre[0].Ejer[0].Tema2
            esco.teoria = arre[0].Teo[0].Tema2
        }else if "\(arre[0].Temas[(myIndexPath?.row)!])" == "\(arre[0].Temas[2])"{
            esco.ejer = arre[0].Ejer[0].Tema3
            esco.teoria = arre[0].Teo[0].Tema3
        }else if "\(arre[0].Temas[(myIndexPath?.row)!])" == "\(arre[0].Temas[3])"{
            esco.ejer = arre[0].Ejer[0].Tema4
            esco.teoria = arre[0].Teo[0].Tema4
        }else if "\(arre[0].Temas[(myIndexPath?.row)!])" == "\(arre[0].Temas[4])"{
            esco.ejer = arre[0].Ejer[0].Tema5
            esco.teoria = arre[0].Teo[0].Tema5
        }else if "\(arre[0].Temas[(myIndexPath?.row)!])" == "\(arre[0].Temas[5])"{
            esco.ejer = arre[0].Ejer[0].Tema6
            esco.teoria = arre[0].Teo[0].Tema6
        }else{
            print("no sirves pafa esto")
        }
    
       
    }
    
    func obtener(str: String){
        let storageReference = Storage.storage().reference()
        let photoDownload = storageReference.child("/Portadas/\(str)")
        
        let placeHolder = UIImage(named: "backup")
        
        portada.sd_setImage(with: photoDownload, placeholderImage: placeHolder)
        
        photoDownload.downloadURL { (url, error) in
            if let error = error{
                print("hubo un error")
                print(error.localizedDescription)
            }else{
              //  print("url: \(String(describing: url!))")
                
            }
        }
    }//aqui termina la función
    @IBAction func cerrar(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
}
