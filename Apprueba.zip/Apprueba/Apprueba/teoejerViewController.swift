//
//  teoejerViewController.swift
//  Apprueba
//
//  Created by 2020-1 on 12/4/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit

class teoejerViewController: UIViewController {
    

    
    var teoria: [String] = []
    var ejer: [String] = []
    var arre: [inf] = [inf]()
    var bolita: IndexPath = []
    var arren: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        print(ejer)
        print(teoria)
        arren = teoria
    }
    
   
    @IBAction func ejer(_ sender: Any) {
       arren = ejer
    }
    @IBAction func teo(_ sender: Any)  {
       arren = teoria
        
            }
    
    @IBAction func cerrar(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let Teja = segue.destination as! TEJViewController
        Teja.arre = arre
        Teja.arren = arren
        
        
    }

}
