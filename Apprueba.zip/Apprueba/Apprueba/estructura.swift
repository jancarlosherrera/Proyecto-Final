//
//  estructura.swift
//  Apprueba
//
//  Created by 2020-1 on 12/4/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import Foundation
struct temario {
    var Tema1: [String]
    var Tema2: [String]
    var Tema3: [String]
    var Tema4: [String]
    var Tema5: [String]
    var Tema6: [String]
    
}
struct inf {
    var Materia: String
    var Temas: [String]
    var Teo: [temario]
    var Ejer: [temario]
}
