//
//  TEJViewController.swift
//  Apprueba
//
//  Created by 2020-1 on 12/3/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import Firebase
import FirebaseUI
import MobileCoreServices

class TEJViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    //cabecera
    var teoria: [temario] = []
    var ejer: [temario] = []
    var arre: [inf] = [inf]()   //finCab
    var arren:[String] = []
    var bolita: IndexPath = []
    
    @IBOutlet weak var tabla: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print(arren.count)
       
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return arren.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tabla.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! TejTableViewCell
        
        let storageReference = Storage.storage().reference()
        let photoDownload = storageReference.child("\(arren[indexPath.row])")
        
        let placeHolder = UIImage(named: "SC")
        
        cell.imagen.sd_setImage(with: photoDownload, placeholderImage: placeHolder)
        
        photoDownload.downloadURL { (url, error) in
            if let error = error{
                print("hubo un error")
                print(error.localizedDescription)
            }else{
                print("url: \(String(describing: url!))")
                
            }
        }
        
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let ft = segue.destination as! UltimViewController
        let myIndexPath = tabla.indexPathForSelectedRow
       ft.foto = arren[(myIndexPath?.row)!]
        
    }
    
    
    @IBAction func cerrar(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}
