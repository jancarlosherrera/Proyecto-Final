//
//  UltimViewController.swift
//  Apprueba
//
//  Created by 2020-1 on 12/4/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import UIKit
import Firebase
import FirebaseUI
import MobileCoreServices

class UltimViewController: UIViewController {
    var foto: String = ""
    
    @IBOutlet weak var imagen: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    obtener(str: foto)
        // Do any additional setup after loading the view.
    }
    func obtener(str: String){
        let storageReference = Storage.storage().reference()
        let photoDownload = storageReference.child("\(str)")
        
        let placeHolder = UIImage(named: "SC")
        
        imagen.sd_setImage(with: photoDownload, placeholderImage: placeHolder)
        
        photoDownload.downloadURL { (url, error) in
            if let error = error{
                print("hubo un error")
                print(error.localizedDescription)
            }else{
                print("url: \(String(describing: url!))")
                
            }
        }
    }

    @IBAction func cerrar(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
