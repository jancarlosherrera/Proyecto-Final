//
//  jason.swift
//  Apprueba
//
//  Created by 2020-1 on 12/3/19.
//  Copyright © 2019 JAN. All rights reserved.
//

import Foundation

struct info: Codable {
    var Materia: String
    var Temas: [String]
    var teoria: [String]
    var ejercicios: [String]
}
